package anu.com.recipes.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import anu.com.recipes.entity.Recipe;
import anu.com.recipes.repository.IRecipeRepository;
import anu.com.recipes.services.IRecipeService;
@Service
public class RecipeServiceImpl implements IRecipeService {

	@Autowired
	IRecipeRepository recipeRepository;
	
	@Override
	public List<Recipe> findAll()
	{
		
		return recipeRepository.findAll();
	}

	@Override
	public Recipe saveRecipe(Recipe recipe)
	{
		
		return recipeRepository.save(recipe);
	}

	@Override
	public Recipe updateRecipe(Recipe recipe) 
	{
		return recipeRepository.save(recipe);
		
	}

	@Override
	public int deleteRecipe(int recipeId)
	{
		recipeRepository.deleteById(recipeId);
		return recipeId;
		
	}

	@Override
	public Recipe getRecipeDetails(int recipeId) 
	{
		
		return recipeRepository.findById(recipeId).get();
	}

	@Override
	public Recipe getRecipeDetails() {
		// TODO Auto-generated method stub
		return null;
	}
	 @Override
	    public Optional<Recipe> findById(int recipeId) {
	        Optional<Recipe> optionalRecipe = recipeRepository.findById(recipeId);
	        return Optional.ofNullable(optionalRecipe.orElse(null));
	    }


}
