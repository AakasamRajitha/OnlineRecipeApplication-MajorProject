package anu.com.recipes.services;
import java.util.List;
import java.util.Optional;

import anu.com.recipes.entity.Recipe;

public interface IRecipeService 
{
  
   
   Recipe saveRecipe(Recipe recipe);
   Recipe updateRecipe(Recipe recipe);
   int deleteRecipe(int recipeId);
   Recipe getRecipeDetails( int recipeId);
   List<Recipe> findAll();
   Recipe getRecipeDetails(); 
   Optional<Recipe> findById(int recipeId);
}
