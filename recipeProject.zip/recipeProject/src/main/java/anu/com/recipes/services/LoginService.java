package anu.com.recipes.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import anu.com.recipes.entity.LoginEntity;
import anu.com.recipes.repository.LoginRepository;
import jakarta.transaction.Transactional;

@Service

public class LoginService 
{
	@Autowired
    private LoginRepository loginRepository;

    public List<LoginEntity> getAllLogins() {
        return loginRepository.findAll();
    }

    public LoginEntity getLoginById(Long id) {
        return loginRepository.findById(id).orElse(null);
    }

    public LoginEntity addLogin(LoginEntity loginEntity) {
        return loginRepository.save(loginEntity);
    }

    public LoginEntity updateLogin(Long id, LoginEntity updatedLogin) {
        LoginEntity existingLogin = loginRepository.findById(id).orElse(null);
        if (existingLogin != null) {
            // Update the fields you want to change
            existingLogin.setUsername(updatedLogin.getUsername());
            existingLogin.setPassword(updatedLogin.getPassword());
            existingLogin.setEmail(updatedLogin.getEmail());
            return loginRepository.save(existingLogin);
        }
        return null; // You can throw an exception or handle the case differently
    }

    public void deleteLogin(Long id) {
        loginRepository.deleteById(id);
    }
}

