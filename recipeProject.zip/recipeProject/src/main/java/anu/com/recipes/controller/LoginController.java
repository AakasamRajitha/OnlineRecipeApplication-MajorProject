package anu.com.recipes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import anu.com.recipes.entity.LoginEntity;
import anu.com.recipes.services.LoginService;

@RestController
@RequestMapping("/api/login")
public class LoginController 
{
	@Autowired
    private LoginService loginService;

    // Get all logins
    @GetMapping("/all")
    public ResponseEntity<List<LoginEntity>> getAllLogins() {
        List<LoginEntity> logins = loginService.getAllLogins();
        return new ResponseEntity<>(logins, HttpStatus.OK);
    }

    // Get a login by ID
    @GetMapping("/{id}")
    public ResponseEntity<LoginEntity> getLoginById(@PathVariable Long id) {
        LoginEntity login = loginService.getLoginById(id);
        return new ResponseEntity<>(login, HttpStatus.OK);
    }

    // Add a new login
    @PostMapping("/add")
    public ResponseEntity<LoginEntity> addLogin(@RequestBody LoginEntity loginEntity) {
        LoginEntity newLogin = loginService.addLogin(loginEntity);
        return new ResponseEntity<>(newLogin, HttpStatus.CREATED);
    }

    // Update an existing login
    @PutMapping("/update/{id}")
    public ResponseEntity<LoginEntity> updateLogin(@PathVariable Long id, @RequestBody LoginEntity updatedLogin) {
        LoginEntity updatedEntity = loginService.updateLogin(id, updatedLogin);
        return new ResponseEntity<>(updatedEntity, HttpStatus.OK);
    }

    // Delete a login
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteLogin(@PathVariable Long id) {
        loginService.deleteLogin(id);
        return new ResponseEntity<>("Login with ID " + id + " deleted successfully", HttpStatus.OK);
    }
}
