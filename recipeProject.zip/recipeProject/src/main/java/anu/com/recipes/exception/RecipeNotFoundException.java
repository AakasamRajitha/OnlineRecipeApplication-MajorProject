package anu.com.recipes.exception;

public class RecipeNotFoundException extends Exception
{

	public RecipeNotFoundException(String message) 
	{
		super(message);
		
	}
 
}
