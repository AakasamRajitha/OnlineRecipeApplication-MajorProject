package anu.com.recipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication

public class RecipeProjectApplication
{

	public static void main(String[] args) 
	{
		SpringApplication.run(RecipeProjectApplication.class, args);
		System.out.println("welcome to java recipe project");	
	}

}
